import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'web-reuse',
  templateUrl: './reuse.component.html',
  styleUrls: ['./reuse.component.scss']
})
export class ReuseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
