import { Directive } from '@angular/core';

@Directive({
  selector: '[appColorHighlight]'
})
export class ColorHighlightDirective {

  constructor() { }

}
