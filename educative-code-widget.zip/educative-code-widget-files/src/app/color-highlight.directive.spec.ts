import { ColorHighlightDirective } from './color-highlight.directive';

describe('ColorHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorHighlightDirective();
    expect(directive).toBeTruthy();
  });
});
